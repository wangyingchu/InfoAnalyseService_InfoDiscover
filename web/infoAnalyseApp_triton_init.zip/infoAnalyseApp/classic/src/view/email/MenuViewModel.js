Ext.define('Admin.view.email.MenuViewModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.emailmenu'
    
    // TODO - Add view data as needed or remove if not used
});
