Ext.namespace('Ext.theme.is').Cupertino = true;
Ext.theme.name = 'Cupertino';
