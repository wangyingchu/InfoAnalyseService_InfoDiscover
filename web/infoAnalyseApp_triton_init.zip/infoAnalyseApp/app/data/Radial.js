Ext.define('Admin.data.Radial', {
    extend: 'Admin.data.Simulated',

    data: [
        {
            "xvalue": "A",
            "yvalue": 417
        },
        {
            "xvalue": "B",
            "yvalue": 676
        },
        {
            "xvalue": "C",
            "yvalue": 606
        },
        {
            "xvalue": "D",
            "yvalue": 124
        },
        {
            "xvalue": "E",
            "yvalue": 473
        },
        {
            "xvalue": "F",
            "yvalue": 108
        },
        {
            "xvalue": "G",
            "yvalue": 847
        },
        {
            "xvalue": "H",
            "yvalue": 947
        },
        {
            "xvalue": "I",
            "yvalue": 694
        },
        {
            "xvalue": "J",
            "yvalue": 603
        }
    ]
});
