Ext.define('Admin.model.PanelSetting', {
    extend: 'Admin.model.Base',

    fields: [
        {
            name: 'title'
        },
        {
            name: 'subTitle'
        },
        {
            name: 'toggleStatus'
        }
    ]
});
