Ext.define('Admin.model.DataXY', {
    extend: 'Admin.model.Base',

    fields: [
        {
            name: 'xvalue'
        },
        {
            name: 'yvalue'
        }
    ]
});
