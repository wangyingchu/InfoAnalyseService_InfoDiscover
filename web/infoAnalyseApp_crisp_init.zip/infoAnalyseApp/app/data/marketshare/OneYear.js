Ext.define('Admin.data.marketshare.OneYear', {
    extend: 'Admin.data.Simulated',

    "data" :[
        {
            "xvalue": 2004,
            "yvalue": 239
        },
        {
            "xvalue": 2005,
            "yvalue": 402
        },
        {
            "xvalue": 2006,
            "yvalue": 706
        },
        {
            "xvalue": 2007,
            "yvalue": 432
        },
        {
            "xvalue": 2008,
            "yvalue": 200
        },
        {
            "xvalue": 2009,
            "yvalue": 763
        },
        {
            "xvalue": 2010,
            "yvalue": 550
        },
        {
            "xvalue": 2011,
            "yvalue": 630
        },
        {
            "xvalue": 2012,
            "yvalue": 278
        },
        {
            "xvalue": 2013,
            "yvalue": 312
        },
        {
            "xvalue": 2014,
            "yvalue": 600
        },
        {
            "xvalue": 2015,
            "yvalue": 283
        }
    ]
});
