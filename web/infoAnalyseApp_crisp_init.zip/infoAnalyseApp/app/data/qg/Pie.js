Ext.define('Admin.data.qg.Pie', {
    extend: 'Admin.data.Simulated',

    data: [
        {
            "xvalue": "Research",
            "yvalue": 68
        },
        {
            "xvalue": "Finance",
            "yvalue": 20
        },
        {
            "xvalue": "Marketing",
            "yvalue": 12
        }
    ]
});
