Ext.define('Admin.data.dashboard.Counce', {
    extend: 'Admin.data.Simulated',

    data: [
        {
            "xvalue": 0,
            "y1value": 15,
            "y2value": 15
        },
        {
            "xvalue": 5,
            "y1value": 20,
            "y2value": 20
        },
        {
            "xvalue": 10,
            "y1value": 15,
            "y2value": 15
        },
        {
            "xvalue": 15,
            "y1value": 16,
            "y2value": 16
        },
        {
            "xvalue": 20,
            "y1value": 14,
            "y2value": 14
        },
        {
            "xvalue": 25,
            "y1value": 18,
            "y2value": 18
        },
        {
            "xvalue": 30,
            "y1value": 10,
            "y2value": 10
        }
    ]
});
