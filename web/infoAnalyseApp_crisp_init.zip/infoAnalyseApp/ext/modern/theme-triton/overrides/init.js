Ext.namespace('Ext.theme.is').Triton = true;
Ext.theme.name = 'Triton';

Ext.theme.getDocCls = function() {
    return Ext.platformTags.phone ? 'x-big' : '';
};
