/**
 * For backward compatibility only.  Use Ext.Widget instead
 * @private
 */
Ext.define('Ext.AbstractComponent', {
    extend: 'Ext.Widget'
});