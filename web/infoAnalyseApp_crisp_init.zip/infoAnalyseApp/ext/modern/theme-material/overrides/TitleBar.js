Ext.define('Ext.theme.material.TitleBar', {
    override: 'Ext.TitleBar',

    config: {
        titleAlign: 'left',
        defaultButtonUI: 'alt'
    }
});
