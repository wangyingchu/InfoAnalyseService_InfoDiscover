Ext.define('Ext.theme.mountainview.MessageBox', {
    override: 'Ext.MessageBox',

    config: {
        buttonToolbar: {
            defaults: {
                flex: 1
            }
        }
    }
});
