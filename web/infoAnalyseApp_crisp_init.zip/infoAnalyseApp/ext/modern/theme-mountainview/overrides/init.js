Ext.namespace('Ext.theme.is').MountainView = true;
Ext.theme.name = 'MountainView';
