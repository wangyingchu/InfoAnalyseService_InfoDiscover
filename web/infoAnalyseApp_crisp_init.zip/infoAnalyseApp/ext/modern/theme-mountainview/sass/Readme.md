# theme-mountainview/sass

This folder contains SASS files of various kinds, organized in sub-folders:

    theme-mountainview/sass/etc
    theme-mountainview/sass/src
    theme-mountainview/sass/var
