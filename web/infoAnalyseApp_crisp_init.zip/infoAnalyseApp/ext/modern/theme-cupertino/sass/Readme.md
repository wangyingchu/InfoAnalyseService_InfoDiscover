# theme-cupertino/sass

This folder contains SASS files of various kinds, organized in sub-folders:

    theme-cupertino/sass/etc
    theme-cupertino/sass/src
    theme-cupertino/sass/var
