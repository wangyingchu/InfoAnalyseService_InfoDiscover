Ext.define('Ext.theme.cupertino.TitleBar', {
    override: 'Ext.TitleBar',

    config: {
        maxButtonWidth: '80%'
    }
});