Ext.define('Ext.theme.ios.TitleBar', {
    override: 'Ext.TitleBar',
    config: {
        defaultButtonUI: null
    }
});
