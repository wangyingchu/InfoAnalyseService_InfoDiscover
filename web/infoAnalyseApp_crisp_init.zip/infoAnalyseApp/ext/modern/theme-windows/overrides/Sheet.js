Ext.define('Ext.theme.windows.Sheet', {
    override: 'Ext.Sheet',

    config: {    
        enter: 'top',
        exit: 'top'
    }
});