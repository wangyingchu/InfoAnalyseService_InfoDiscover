Ext.define('Ext.theme.windows.ActionSheet', {
    override: 'Ext.ActionSheet',
    
    config: {
        top: 0,
        bottom: null
    }
});