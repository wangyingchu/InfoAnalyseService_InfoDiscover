# theme-windows/sass

This folder contains SASS files of various kinds, organized in sub-folders:

    theme-windows/sass/etc
    theme-windows/sass/src
    theme-windows/sass/var
