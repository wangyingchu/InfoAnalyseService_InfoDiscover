Ext.define('Ext.theme.blackberry.TitleBar', {
    override: 'Ext.TitleBar',

    config: {
        titleAlign: 'left'
    }
});