Ext.namespace('Ext.theme.is').BlackBerry = true;
Ext.theme.name = 'BlackBerry';
