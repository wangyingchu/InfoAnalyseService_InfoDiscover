Ext.define('Ext.theme.aria.Component', {
    override: 'Ext.Component'
}, function() {
    Ext.namespace('Ext.theme.is').Aria = true;
    Ext.theme.name = 'Aria';
});