Ext.define('Admin.view.search.ResultsController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.searchresults'

    // TODO - Add control logic or remove is not needed
});
