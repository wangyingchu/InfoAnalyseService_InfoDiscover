Ext.define('Admin.data.qg.Bar', {
    extend: 'Admin.data.Simulated',

    data: [
        {
            "xvalue": 0,
            "yvalue": 600
        },
        {
            "xvalue": 10,
            "yvalue": 748
        },
        {
            "xvalue": 20,
            "yvalue": 569
        },
        {
            "xvalue": 30,
            "yvalue": 850
        },
        {
            "xvalue": 40,
            "yvalue": 500
        },
        {
            "xvalue": 50,
            "yvalue": 753
        },
        {
            "xvalue": 60,
            "yvalue": 707
        },
        {
            "xvalue": 70,
            "yvalue": 640
        }
    ]
});
